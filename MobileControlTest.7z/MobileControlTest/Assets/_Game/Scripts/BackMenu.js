var skin : GUISkin;

function OnGUI () {
	if(skin) {
		GUI.skin = skin;
	}
	var w = 80;
	var h = 20;
	var x = 5;
	var y = Screen.height - h - 10;
	if(GUI.Button(Rect(x, y, w, h), "Main Menu")) {
		Application.LoadLevel("Menu");
	}
}