var skin : GUISkin;

var gameLevels : String[] = [
	"Level1",
	"Level2",
	"Level3",
	"Level4",
	"Level5",
	"Level6"
];

var levelNames : String[] = [
	"Camera Relative Setup",
	"First Person Setup",
	"First Person Tilt",
	"Player Relative Setup",
	"Sidescroll Setup",
	"Tap Control Setup"
];

private var menuWindow : Rect;

function OnGUI () {
	if(skin) {
		GUI.skin = skin;
	}
    var w = 220;
    var h = gameLevels.length * 35 + 50;
    var x = (Screen.width - w)/ 2;
    var y = 50;
    menuWindow = GUI.Window (0, Rect (x, y, w, h), drawMenuWindow, "Game Menu");
}

function drawMenuWindow (windowID : int) {
	var w = 180;
	var h = 30;
	var x = (menuWindow.width - w)/2;
	var y = 35;
	var offset = 5;
	for(var i = 0; i < gameLevels.length; i++) {
	    if (GUI.Button (Rect(x, y, w, h), levelNames[i])) {
	    	Application.LoadLevel( gameLevels[i] );
	    }
	    y += h + offset;
	}
    GUI.DragWindow (Rect (0,0,10000,10000));
}
