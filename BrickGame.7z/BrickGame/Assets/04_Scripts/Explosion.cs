﻿using UnityEngine;
using System.Collections;

public class Explosion : MonoBehaviour {
	public AudioClip sound;
	public float lifeTime = 1.0f;
	
	// Use this for initialization
	void Start () {
		if(sound) {
			//Debug.Log ("play sound");
			audio.PlayOneShot(sound);
		}
		Destroy(gameObject, lifeTime);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
