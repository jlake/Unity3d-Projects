﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MainMenu : MonoBehaviour {
	public GUISkin guiSkin;

	private Rect menuRect;
	private Dictionary<string, string> menuItems = new Dictionary<string, string>(){
		{"Level1", "Level1"},
		{"Level2", "Level2"},
		//{"Options", "Options"}
	};

	void OnGUI() {
		if(guiSkin) {
			GUI.skin = guiSkin;
		}
		float w = 220;
		float h = menuItems.Count * 35 + 50;
		float x = (Screen.width - w)/ 2;
		float y = 50;
		menuRect = GUI.Window(0, new Rect(x, y, w, h), drawMenuWindow, "Game Menu");
	}

	void drawMenuWindow(int windowId) {
		float w = 180;
		float h = 30;
		float x = (menuRect.width - w)/2;
		float y = 35;
		float offset = 5;
		foreach (KeyValuePair<string, string> pair in menuItems) {
			//Debug.Log(string.Format("Key : {0} / Value : {1}", pair.Key, pair.Value));
			if (GUI.Button(new Rect(x, y, w, h), pair.Value)) {
				Application.LoadLevel(pair.Key);
			}
			y += h + offset;
		}
		GUI.DragWindow(new Rect(0, 0, 10000, 10000));
	}
}
