﻿using UnityEngine;
using System.Collections;

public class GameController : MonoBehaviour {
	
	public GameObject paddle;
	public GameObject ballPrefab;
	public GUISkin guiSkin;
	
	private GameObject ball = null;
	private bool isFired = false;
	
	private int lives = 4;
	private int score = 0;
	public static int lastLevel;
	
	// Use this for initialization
	void Start () {
		lastLevel = Application.loadedLevel;
		//Debug.Log ("currentLevel:" + currentLevel);
		spawnBall();
	}
	
	// Update is called once per frame
	void Update () {
		if(ball == null) return;
		if (!isFired) {
			if(Input.GetButton("LaunchBall")) {
				//Debug.Log ("LaunchBall");
				//ball.rigidbody.isKinematic = false;
				ball.rigidbody.AddForce(new Vector3(Paddle.xForce * Input.GetAxis("Horizontal"), 300.0f, 0));
				isFired = true;
			} else {
				ball.transform.position = paddle.transform.position + new Vector3(0, 0.4f, 0);
			}
		}
	}
	
	void OnGUI() {
		if(guiSkin) {
			GUI.skin = guiSkin;
		}
		float w = 200;
		float h = 30;
		float x = 5;
		float y = Screen.height - h;
		GUI.Label(new Rect(x, y, w, h), "Lives:" + lives);
		GUI.Label(new Rect(x, y - h, w, h), "Score:" + score);
	}
	
	public void spawnBall() {
		if(lives <= 0) {
			Application.LoadLevel("GameOver");
			return;
		}
		isFired = false;
		if(paddle == null) {
			paddle = GameObject.Find("Paddle");
		}
		if(ballPrefab != null) {
			ball = Instantiate(ballPrefab, paddle.transform.position + new Vector3(0, 0.4f, 0), Quaternion.identity) as GameObject;
			//Debug.Log ("ball Instantiated");
			lives--;
		}
	}
	
	public void AddScore(int v) {
		score += v;
	}
	
	public void LoadNextLevel() {
		try {
			Application.LoadLevel(Application.loadedLevel + 1);
		} catch {
			Debug.Log ("Next level does not exists");
		}
	}
}
