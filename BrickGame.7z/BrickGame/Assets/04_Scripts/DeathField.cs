﻿using UnityEngine;
using System.Collections;

public class DeathField : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnTriggerEnter(Collider other) {
		//Debug.Log("Dead object tag:" + other.gameObject.tag);
		Destroy(other.gameObject);
		if(other.gameObject.tag == "Ball") {
			GameController gameCongroller = GameObject.Find("GameController").GetComponent<GameController>();
			gameCongroller.spawnBall();
		}
	}
}
