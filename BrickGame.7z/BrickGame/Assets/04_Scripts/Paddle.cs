﻿using UnityEngine;
using System.Collections;

public class Paddle : MonoBehaviour {
	public float moveSpeed = 10.0f;
	public static float xForce = 300.0f;
	public GameObject wallLeft;
	public GameObject wallRight;
	
	private float minX = -3.5f;
	private float maxX = 3.5f;
	
	// Use this for initialization
	void Start () {
		if(wallLeft) minX = wallLeft.transform.position.x + wallLeft.transform.lossyScale.y / 2 + transform.lossyScale.x / 2;
		if(wallRight) maxX = wallRight.transform.position.x - wallRight.transform.lossyScale.y / 2 - transform.lossyScale.x / 2;
		//Debug.Log("minX=" + minX + " maxX=" + maxX);
	}
	
	// Update is called once per frame
	void Update () {
		float hAxis = Input.GetAxis("Horizontal");
		//Debug.Log("hAxis=" + hAxis);
		transform.Translate(moveSpeed * Time.deltaTime * hAxis, 0, 0);
		if(transform.position.x < minX) {
			transform.position = new Vector3(minX, transform.position.y, transform.position.z);
		}
		if(transform.position.x > maxX) {
			transform.position = new Vector3(maxX, transform.position.y, transform.position.z);
		}
	}
	
	void OnCollisionEnter(Collision collision) {
		//Debug.Log ("OnCollisionEnter");
		foreach (ContactPoint contact in collision.contacts) {
            //Debug.DrawRay(contact.point, contact.normal, Color.white);
			if(contact.thisCollider == collider) {
				float xOffset = contact.point.x - transform.position.x;
				contact.otherCollider.rigidbody.AddForce(xForce * xOffset, 0, 0);
			}
        }
	}
}
