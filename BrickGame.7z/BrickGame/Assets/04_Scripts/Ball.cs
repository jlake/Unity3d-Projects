﻿using UnityEngine;
using System.Collections;

public class Ball : MonoBehaviour {

	// Use this for initialization
	void Start () {
		//transform.position = new Vector3(0, -3.0f, -0.5f);
		//rigidbody.AddForce(new Vector3(0, -300.0f, 0));
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
