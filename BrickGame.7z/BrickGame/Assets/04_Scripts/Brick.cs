﻿using UnityEngine;
using System.Collections;

public class Brick : MonoBehaviour {
	public int pointValue = 1;
	public int hitPoints = 1;
	
	public GameObject explosion;
	
	static int numBricks = 0;
	
	// Use this for initialization
	void Start () {
		numBricks++;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnCollisionEnter(Collision collision) {
		hitPoints--;
		if(hitPoints <=0) {
			Die();
		}
	}
	
	public void Die() {
		Destroy(gameObject);
		if(explosion) {
			Debug.Log("explosion");
			Instantiate(explosion, transform.position, Quaternion.identity);
		}
		GameController gameCongroller = GameObject.Find("GameController").GetComponent<GameController>();
		gameCongroller.AddScore(pointValue);
		numBricks--;
		//Debug.Log("numBricks=" + numBricks);
		if(numBricks <=0) {
			gameCongroller.LoadNextLevel();
		}
	}
}
