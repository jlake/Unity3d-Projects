﻿using UnityEngine;
using System.Collections;

public class GameOver : MonoBehaviour {
	public GUISkin guiSkin;
	public GUIText gameOverText;
	public int startSize = 1;
	public int endSize = 40;
	
	private int currentSize;
	private Rect menuRect;

	void OnGUI() {
		if(guiSkin) {
			GUI.skin = guiSkin;
		}
		float w = 220;
		float h = 120;
		float x = (Screen.width - w)/ 2;
		float y = 50;
		menuRect = GUI.Window(0, new Rect(x, y, w, h), drawMenuWindow, "Game Menu");
	}

	void drawMenuWindow(int windowId) {
		float w = 180;
		float h = 30;
		float x = (menuRect.width - w)/2;
		float y = 35;
		float offset = 5;
		if(GUI.Button(new Rect(x, y, w, h), "Main Menu")) {
			Application.LoadLevel("MainMenu");
		}
		if(GUI.Button(new Rect(x, y + h + offset, w, h), "Retry")) {
			Application.LoadLevel(GameController.lastLevel);
		}
		GUI.DragWindow(new Rect(0, 0, 10000, 10000));
	}

	
	// Use this for initialization
	void Start () {
		currentSize = startSize;
		gameOverText.fontSize = currentSize;
	}
	
	// Update is called once per frame
	void Update () {
		if(currentSize < endSize) {
			currentSize++;
			gameOverText.fontSize = currentSize;
		}
	}
}
